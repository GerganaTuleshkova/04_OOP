def is_empty_string(string):
    return string.strip() == ""


def is_not_positive(value):
    return value <= 0
