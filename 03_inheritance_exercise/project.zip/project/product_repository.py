from project.product import Product


class ProductRepository:
    def __init__(self):
        self.products = []

    def add(self, product: Product):
        self.products.append(product)

    def find(self, product_name: str):
        for product_obj in self.products:
            if product_obj.name == product_name:
                return product_obj

    def remove(self, product_name: str):
        for product_obj in self.products:
            if product_obj.name == product_name:
                self.products.remove(product_obj)

    def __repr__(self):
        resulting_string = []
        for product_obj in self.products:
            resulting_string.append(f"{product_obj.name}: {product_obj.quantity}")
        return "\n".join(resulting_string)
        #return f"{' '.join([f'{product_obj.name}: {product_obj.quantity}' for project_obj in self.products])}"
